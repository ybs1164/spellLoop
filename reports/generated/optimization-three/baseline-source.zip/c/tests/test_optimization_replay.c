#include "world.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned long long digest=1469598103934665603ull;
static void hash(const void *ptr,size_t n){const unsigned char *p=ptr;while(n--){digest^=*p++;digest*=1099511628211ull;}}
#define H(v) hash(&(v),sizeof(v))
int main(int argc,char **argv){
  int seed=argc>1?atoi(argv[1]):1,mode=argc>2?atoi(argv[2]):0,ticks=argc>3?atoi(argv[3]):2400;
  char err[256];if(!data_init(err,sizeof err))return 2;cards_impl_init();World*w=world_create(seed);game_new(w);
  int p=ent_index(w,w->player); SimInput in={{0,0}};
  if(mode==1){
    const char *defs[][9]={{"nearestEnemy","frost","chain","poison"},{"ahead","decoy","turret"},{"randomPoint","archer","mine"},{"self","heal","shield"}};
    for(int k=1;k<6;k++){Slot*s=slot_of(w,w->player,k);if(!s)break;s->n=0;for(int j=0;k<=4&&j<9&&defs[k-1][j];j++)s->cards[s->n++]=card_find(defs[k-1][j]);}
  }
  if(mode==2){
    w->spawn_acc=-1e9f;w->barrel_cd=1e9f;w->next_swarm=1e9f;
    Ctx c={.w=w,.actor=p,.owner=p,.rule=RULE_NONE};
    for(int i=0;i<400;i++){float x=(i%20-10)*42,y=(i/20-10)*32;int e=ent_index(w,spawn_enemy(w,i%2?ENEMY_GRUNT:ENEMY_RUNNER,x,y));w->hp[e]=w->stat[e][STAT_MAX_HP]=1e9f;}
    for(int i=0;i<200;i++)spawn_shot(&c,i%20*32-320,i/20*32-160,120,30,5,1,0,100,1000,0x8BE9FFFFu,SHAPE_DOT);
    for(int i=0;i<5;i++){spawn_placed(&c,OBJ_DECOY,(Vec2){100+i*30,150},NULL);spawn_ally(&c,ALLY_KIND_KNIGHT,(Vec2){-100-i*30,-150});}
  }
  if(mode==3) {
    w->spawn_acc=-1e9f;w->barrel_cd=1e9f;w->next_swarm=1e9f;
    for(int i=0;i<3000;i++){
      int e=ent_index(w,spawn_enemy(w,i%3==0?ENEMY_GRUNT:i%3==1?ENEMY_RUNNER:ENEMY_BRUTE,(i%75-37)*13,(i/75-20)*15));
      w->hp[e]=w->stat[e][STAT_MAX_HP]=1e9f;
    }
  }
  for(int t=0;t<ticks&&w->state==GS_PLAYING;t++){
    w->hp[p]=w->stat[p][STAT_MAX_HP];
    float a=(float)w->time*.6f;in.move=(Vec2){-sinf(a),cosf(a)};
    sim_step(w,&in);
  }
  if(argc>5) {
    FILE *file=fopen(argv[5],"rb");if(!file)return 3;
    fseek(file,0,SEEK_END);long len=ftell(file);rewind(file);
    if(len<=0){fclose(file);return 3;}
    uint8_t *bytes=malloc((size_t)len);bool read=fread(bytes,1,(size_t)len,file)==(size_t)len;fclose(file);
    World *loaded=world_create(1);bool ok=read&&save_read(loaded,bytes,(size_t)len);free(bytes);
    if(!ok){world_destroy(loaded);world_destroy(w);return 4;}
    world_destroy(w);w=loaded;
  }
  if(argc>4 && strcmp(argv[4],"-")) {
    size_t len=save_write(w,NULL,0);uint8_t *bytes=malloc(len);save_write(w,bytes,len);
    FILE *file=fopen(argv[4],"wb");if(!file){free(bytes);return 3;}
    bool ok=fwrite(bytes,1,len,file)==len;fclose(file);free(bytes);if(!ok)return 3;
  }
  H(w->hi);H(w->free_head);H(w->player);H(w->state);H(w->tick);H(w->time);H(w->kills);H(w->xp);H(w->level);H(w->rng);H(w->fx_rng);
#define FIELD(type,name) hash(w->name,sizeof(type)*(size_t)w->hi);
  ENTITY_FIELDS(FIELD)
#undef FIELD
  hash(w->stat,sizeof w->stat[0]*w->hi);hash(w->cbuff,sizeof w->cbuff[0]*w->hi);hash(w->marks,sizeof w->marks[0]*w->hi);hash(w->burns,sizeof w->burns[0]*w->hi);hash(w->hit_mem,sizeof w->hit_mem[0]*w->hi);
  H(w->slot_hi);H(w->slot_free);
  for(int i=0;i<w->hi;i++) {
#define EF(name) H(w->eff[i].name)
    EF(mask);EF(hit_rule);EF(aff_elem);EF(move_target.kind);EF(move_target.player_sel);EF(move_target.h);EF(move_target.x);EF(move_target.y);
    EF(move_speed);EF(keep);EF(hit_damage);EF(hit_knock);EF(decoy_range);EF(guard_reduction);EF(guard_front);EF(aff_mul);EF(resist_freeze);
    EF(fear_immune);EF(hit_pierce_set);EF(hit_pierce);EF(hit_repeat);EF(orbit_count);EF(orbit_speed);EF(orbit_r);
    EF(boom_accel);EF(boom_max);EF(boom_collect);EF(homing_turn);EF(homing_range);EF(armor_reduction);
#undef EF
  }
  H(w->ntexts);hash(w->texts,sizeof w->texts[0]*w->ntexts);
  H(w->nparts);hash(w->parts,sizeof w->parts[0]*w->nparts);
  H(w->nefx);hash(w->efx,sizeof w->efx[0]*w->nefx);
  for(int k=0;k<w->slot_hi;k++){const Slot*s=&w->slots[k];H(s->owner);H(s->cards);H(s->vars);H(s->n);H(s->linked);H(s->cd);H(s->link_expires);H(s->link_actor);H(s->enter);H(s->nenter);H(s->enter_any);H(s->next);}
  printf("{\"seed\":%d,\"mode\":%d,\"ticks\":%llu,\"hash\":\"%016llx\",\"kills\":%d,\"hi\":%d,\"slots\":%d}\n",seed,mode,(unsigned long long)w->tick,digest,w->kills,w->hi,w->slot_hi);
  world_destroy(w);return 0;
}
